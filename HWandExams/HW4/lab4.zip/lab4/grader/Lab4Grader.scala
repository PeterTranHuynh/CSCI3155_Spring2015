object Lab4Grader {
  def main(args: Array[String]) {
    (new Lab4Grading).execute(stats = true)
  }
}
