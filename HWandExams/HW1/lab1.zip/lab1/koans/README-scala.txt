This is the "exercises" version.  The working koans are 
at http://bitbucket.org/dickwall/scala-koans/wiki/Home for more details and answers on scala-koans
